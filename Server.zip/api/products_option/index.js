const express = require('express');
const router = express.Router();
const optionController = require('./ProductOptionController')

module.exports = router;