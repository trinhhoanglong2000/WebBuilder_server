const express = require('express');
const router = express.Router();
const variantController = require('./VariantsController')

module.exports = router;